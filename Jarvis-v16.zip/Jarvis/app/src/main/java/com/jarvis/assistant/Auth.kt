package com.jarvis.assistant

import android.content.Context
import android.os.SystemClock
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

enum class AuthStatus { OK, WRONG, LOCKED_OUT, NOT_SET }

data class AuthResult(
    val status: AuthStatus,
    val attemptsLeft: Int = 0,
    val lockSecs: Long = 0L,
    val justLocked: Boolean = false
)

/** "3 minutes" style text for spoken lock-out messages. */
fun minutesText(secs: Long): String {
    val m = (secs + 59L) / 60L
    return if (m <= 1L) "1 minute" else "" + m + " minutes"
}

/**
 * Local passcode check. The passcode is never stored in readable form: only a salted PBKDF2 hash is kept,
 * inside the Keystore-encrypted preferences. The "unlocked" state lives only in memory, so restarting
 * the app or the phone always locks Jarvis again. Nothing here is ever sent to an AI service.
 */
object Auth {
    private const val MAX_ATTEMPTS = 3
    private const val LOCKOUT_MS = 5L * 60L * 1000L
    private const val ITERATIONS = 120_000

    @Volatile private var unlockedUntil = 0L
    @Volatile private var storeRef: SecureStore? = null

    fun setup(ctx: Context) {
        if (storeRef == null) {
            synchronized(this) {
                if (storeRef == null) storeRef = SecureStore(ctx.applicationContext)
            }
        }
    }

    private fun store(): SecureStore = storeRef ?: throw IllegalStateException("Auth is not initialised")

    fun isSet(): Boolean = store().passHash.isNotEmpty()

    fun isUnlocked(): Boolean = SystemClock.elapsedRealtime() < unlockedUntil

    fun unlock() { unlockedUntil = SystemClock.elapsedRealtime() + store().timeoutMin * 60_000L }

    /** Called on every authorised action so the timeout counts from the last use. */
    fun touch() { if (isUnlocked()) unlock() }

    fun lock() { unlockedUntil = 0L }

    fun lockoutSecs(): Long {
        val left = store().lockUntil - System.currentTimeMillis()
        return if (left > 0L) (left + 999L) / 1000L else 0L
    }

    private fun normalize(input: String): String =
        input.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }

    private fun hash(code: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(code.toCharArray(), salt, ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun matches(input: String, s: SecureStore): Boolean {
        val n = normalize(input)
        if (n.isEmpty() || s.passSalt.isEmpty()) return false
        val expected = Base64.decode(s.passHash, Base64.NO_WRAP)
        val actual = hash(n, Base64.decode(s.passSalt, Base64.NO_WRAP))
        return MessageDigest.isEqual(expected, actual)
    }

    /** Checks an attempt. Wrong attempts are counted; three in a row lock verification for five minutes. */
    @Synchronized
    fun verify(input: String): AuthResult {
        val s = store()
        if (s.passHash.isEmpty()) return AuthResult(AuthStatus.NOT_SET)
        val locked = lockoutSecs()
        if (locked > 0L) return AuthResult(AuthStatus.LOCKED_OUT, 0, locked)
        if (matches(input, s)) {
            s.failCount = 0
            s.lockUntil = 0L
            unlock()
            return AuthResult(AuthStatus.OK)
        }
        val n = s.failCount + 1
        if (n >= MAX_ATTEMPTS) {
            s.failCount = 0
            s.lockUntil = System.currentTimeMillis() + LOCKOUT_MS
            lock()
            return AuthResult(AuthStatus.LOCKED_OUT, 0, LOCKOUT_MS / 1000L, true)
        }
        s.failCount = n
        return AuthResult(AuthStatus.WRONG, MAX_ATTEMPTS - n)
    }

    /** Sets a new passcode. Callers must already have verified the owner (first run, or the current passcode). */
    @Synchronized
    fun setPasscode(newCode: String): Boolean {
        val n = normalize(newCode)
        if (n.length < 3) return false
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val s = store()
        s.passSalt = Base64.encodeToString(salt, Base64.NO_WRAP)
        s.passHash = Base64.encodeToString(hash(n, salt), Base64.NO_WRAP)
        s.failCount = 0
        s.lockUntil = 0L
        return true
    }
}

/** Fingerprint / face / phone PIN prompt supplied by Android. */
object DeviceAuth {
    private val allowed = BiometricManager.Authenticators.BIOMETRIC_WEAK or
        BiometricManager.Authenticators.DEVICE_CREDENTIAL

    fun available(ctx: Context): Boolean =
        BiometricManager.from(ctx).canAuthenticate(allowed) == BiometricManager.BIOMETRIC_SUCCESS

    fun prompt(activity: FragmentActivity, title: String, onResult: (Boolean) -> Unit) {
        val executor = ContextCompat.getMainExecutor(activity)
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(allowed)
            .build()
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onResult(true) }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onResult(false) }
        })
        prompt.authenticate(info)
    }
}
