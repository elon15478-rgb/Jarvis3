package com.jarvis.assistant

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray

/** Everything sensitive (API key, name, remembered facts) is encrypted on-device. */
class SecureStore(ctx: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        ctx, "jarvis_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) = prefs.edit().putString("api_key", v.trim()).apply()

    var ownerName: String
        get() = prefs.getString("owner", "Sam") ?: "Sam"
        set(v) = prefs.edit().putString("owner", v.trim()).apply()

    var provider: AiProvider
        get() = try { AiProvider.valueOf(prefs.getString("provider", "GEMINI") ?: "GEMINI") } catch (e: Exception) { AiProvider.GEMINI }
        set(v) = prefs.edit().putString("provider", v.name).apply()

    var geminiKey: String
        get() = prefs.getString("gemini_key", "") ?: ""
        set(v) = prefs.edit().putString("gemini_key", v.trim()).apply()

    fun model(p: AiProvider): String = prefs.getString("model_" + p.name, "") ?: ""
    fun setModel(p: AiProvider, v: String) = prefs.edit().putString("model_" + p.name, v.trim()).apply()

    var backendUrl: String
        get() = prefs.getString("backend_url", "") ?: ""
        set(v) = prefs.edit().putString("backend_url", v.trim()).apply()

    var backendToken: String
        get() = prefs.getString("backend_token", "") ?: ""
        set(v) = prefs.edit().putString("backend_token", v.trim()).apply()

    var wakeWord: String
        get() = (prefs.getString("wake_word", "jarvis") ?: "jarvis").ifBlank { "jarvis" }
        set(v) = prefs.edit().putString("wake_word", v.trim().ifBlank { "jarvis" }).apply()

    var wakeEnabled: Boolean
        get() = prefs.getBoolean("wake_on", false)
        set(v) = prefs.edit().putBoolean("wake_on", v).apply()

    val memories: List<String>
        get() = (prefs.getString("mem", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun remember(fact: String) {
        val all = memories + fact.replace("\n", " ").trim()
        prefs.edit().putString("mem", all.takeLast(50).joinToString("\n")).apply()
    }

    init {
        // One-time switch of the default wake word to the new name.
        if (!prefs.getBoolean("renamed_jarvis_back", false)) {
            prefs.edit().putString("wake_word", "jarvis").putBoolean("renamed_jarvis_back", true).apply()
        }
    }

    var readAloud: Boolean
        get() = prefs.getBoolean("read_aloud", false)
        set(v) = prefs.edit().putBoolean("read_aloud", v).apply()

    var remindersJson: String
        get() = prefs.getString("reminders", "") ?: ""
        set(v) = prefs.edit().putString("reminders", v).apply()

    var passHash: String
        get() = prefs.getString("pass_hash", "") ?: ""
        set(v) = prefs.edit().putString("pass_hash", v).apply()

    var passSalt: String
        get() = prefs.getString("pass_salt", "") ?: ""
        set(v) = prefs.edit().putString("pass_salt", v).apply()

    var failCount: Int
        get() = prefs.getInt("fail_count", 0)
        set(v) = prefs.edit().putInt("fail_count", v).apply()

    var lockUntil: Long
        get() = prefs.getLong("lock_until", 0L)
        set(v) = prefs.edit().putLong("lock_until", v).apply()

    var timeoutMin: Int
        get() = prefs.getInt("timeout_min", 5)
        set(v) = prefs.edit().putInt("timeout_min", v).apply()

    var bioUnlock: Boolean
        get() = prefs.getBoolean("bio_unlock", false)
        set(v) = prefs.edit().putBoolean("bio_unlock", v).apply()

    var sensitiveAuth: Boolean
        get() = prefs.getBoolean("sensitive_auth", false)
        set(v) = prefs.edit().putBoolean("sensitive_auth", v).apply()

    var offlineMode: Boolean
        get() = prefs.getBoolean("offline_mode", false)
        set(v) = prefs.edit().putBoolean("offline_mode", v).apply()

    var voiceGender: String
        get() = prefs.getString("voice_gender", "male") ?: "male"
        set(v) = prefs.edit().putString("voice_gender", v).apply()

    var voiceName: String
        get() = prefs.getString("voice_name", "") ?: ""
        set(v) = prefs.edit().putString("voice_name", v).apply()

    fun aiConfig(): AiConfig {
        val p = provider
        return AiConfig(p, if (p == AiProvider.GEMINI) geminiKey else apiKey, model(p), backendUrl, backendToken, liveSearch)
    }

    // ---- notification monitoring, messaging, calls, proactive jobs ----
    var allowedAppsJson: String
        get() = prefs.getString("allowed_apps", "") ?: ""
        set(v) = prefs.edit().putString("allowed_apps", v).apply()

    var autoReplyAppsJson: String
        get() = prefs.getString("autoreply_apps", "") ?: ""
        set(v) = prefs.edit().putString("autoreply_apps", v).apply()

    fun allowedApps(): Set<String> = readSet(allowedAppsJson, DEFAULT_APPS)
    fun saveAllowedApps(s: Set<String>) { allowedAppsJson = JSONArray(s.toList()).toString() }
    fun autoReplyApps(): Set<String> = readSet(autoReplyAppsJson, DEFAULT_AUTOREPLY)
    fun saveAutoReplyApps(s: Set<String>) { autoReplyAppsJson = JSONArray(s.toList()).toString() }

    private fun readSet(raw: String, fallback: Set<String>): Set<String> {
        if (raw.isEmpty()) return fallback
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }.toSet()
        } catch (e: Exception) { fallback }
    }

    var liveSearch: Boolean
        get() = prefs.getBoolean("live_search", true)
        set(v) = prefs.edit().putBoolean("live_search", v).apply()

    var smartReplies: Boolean
        get() = prefs.getBoolean("smart_replies", false)
        set(v) = prefs.edit().putBoolean("smart_replies", v).apply()

    var skipCodes: Boolean
        get() = prefs.getBoolean("skip_codes", true)
        set(v) = prefs.edit().putBoolean("skip_codes", v).apply()

    var busyMode: Boolean
        get() = prefs.getBoolean("busy_mode", false)
        set(v) = prefs.edit().putBoolean("busy_mode", v).apply()

    var busyCallRule: String
        get() = prefs.getString("busy_call_rule", "silence") ?: "silence"
        set(v) = prefs.edit().putString("busy_call_rule", v).apply()

    var autoReply: Boolean
        get() = prefs.getBoolean("auto_reply", false)
        set(v) = prefs.edit().putBoolean("auto_reply", v).apply()

    var autoReplyText: String
        get() = prefs.getString("auto_reply_text", DEFAULT_REPLY) ?: DEFAULT_REPLY
        set(v) = prefs.edit().putString("auto_reply_text", v).apply()

    var autoAnswer: Boolean
        get() = prefs.getBoolean("auto_answer", false)
        set(v) = prefs.edit().putBoolean("auto_answer", v).apply()

    var directCall: Boolean
        get() = prefs.getBoolean("direct_call", false)
        set(v) = prefs.edit().putBoolean("direct_call", v).apply()

    var briefingOn: Boolean
        get() = prefs.getBoolean("briefing_on", false)
        set(v) = prefs.edit().putBoolean("briefing_on", v).apply()

    var briefingHour: Int
        get() = prefs.getInt("briefing_hour", 8)
        set(v) = prefs.edit().putInt("briefing_hour", v).apply()

    var briefingMin: Int
        get() = prefs.getInt("briefing_min", 0)
        set(v) = prefs.edit().putInt("briefing_min", v).apply()

    var briefingLastDay: Int
        get() = prefs.getInt("briefing_last_day", -1)
        set(v) = prefs.edit().putInt("briefing_last_day", v).apply()

    var proactiveOn: Boolean
        get() = prefs.getBoolean("proactive_on", false)
        set(v) = prefs.edit().putBoolean("proactive_on", v).apply()

    var lowBatteryNotified: Boolean
        get() = prefs.getBoolean("low_battery_notified", false)
        set(v) = prefs.edit().putBoolean("low_battery_notified", v).apply()

    var historyJson: String
        get() = prefs.getString("history", "") ?: ""
        set(v) = prefs.edit().putString("history", v).apply()

    companion object {
        const val DEFAULT_REPLY = "I'm busy right now and will reply later. (This is an automated reply from my assistant.)"
        val DEFAULT_APPS = setOf(
            "com.whatsapp", "com.whatsapp.w4b", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
            "com.google.android.apps.messaging"
        )
        val DEFAULT_AUTOREPLY = setOf("com.whatsapp")
        @Volatile private var cached: SecureStore? = null

        /** One shared instance for the whole process. */
        fun of(ctx: Context): SecureStore =
            cached ?: synchronized(this) { cached ?: SecureStore(ctx.applicationContext).also { cached = it } }
    }

    fun forgetAll() = prefs.edit().remove("mem").apply()
}
