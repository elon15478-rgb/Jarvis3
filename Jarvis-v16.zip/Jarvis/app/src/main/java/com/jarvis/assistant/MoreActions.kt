package com.jarvis.assistant

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat

/** More phone controls: websites, flashlight, Do Not Disturb, ringer, connectivity panels, answering calls, screen control. */
object MoreActions {
    private val rx = RegexOption.IGNORE_CASE

    private fun m(p: String, s: String) = Regex(p, rx).matchEntire(s)

    private fun has(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun start(ctx: Context, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true
    } catch (e: Exception) { false }

    private fun torch(ctx: Context, on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (id == null) "This phone has no flashlight." else {
            cm.setTorchMode(id, on)
            if (on) "Flashlight on." else "Flashlight off."
        }
    } catch (e: Exception) { "I couldn't switch the flashlight." }

    fun handle(ctx: Context, s: String): ActionResult? {
        m("(?:open|go to|visit)(?: the)?(?: website| site| page)? ((?:https?://)?[a-z0-9-]+(?:\\.[a-z0-9-]+)+(?:/\\S*)?)", s)?.let { r ->
            var url = r.groupValues[1]
            if (!url.startsWith("http", true)) url = "https://$url"
            val ok = start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            return ActionResult.Done(if (ok) "Opening " + r.groupValues[1] + "." else "I couldn't open that website.")
        }
        m("(?:turn |switch )?(on|off) (?:the )?(?:flashlight|torch)|(?:turn |switch )?(?:the )?(?:flashlight|torch) (on|off)", s)?.let { r ->
            val on = r.groupValues[1].ifEmpty { r.groupValues[2] }.lowercase() == "on"
            return ActionResult.Done(torch(ctx, on))
        }
        m("(?:turn |switch )?(on|off) (?:do not disturb|dnd)(?: mode)?|(?:do not disturb|dnd)(?: mode)? (on|off)", s)?.let { r ->
            val on = r.groupValues[1].ifEmpty { r.groupValues[2] }.lowercase() == "on"
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!nm.isNotificationPolicyAccessGranted) {
                start(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                return ActionResult.Done("I need Do Not Disturb access. I've opened the setting. Allow Jarvis there, then ask again.")
            }
            nm.setInterruptionFilter(
                if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            return ActionResult.Done(if (on) "Do Not Disturb is on." else "Do Not Disturb is off.")
        }
        m("(?:set |put |switch )?(?:the )?(?:phone |ringer )?(?:to |on )?(silent|vibrate|normal) mode|(?:set|put|switch) (?:the )?(?:phone|ringer) (?:to |on )?(silent|vibrate|normal)", s)?.let { r ->
            val mode = r.groupValues[1].ifEmpty { r.groupValues[2] }.lowercase()
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            return try {
                am.ringerMode = when (mode) {
                    "silent" -> AudioManager.RINGER_MODE_SILENT
                    "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                    else -> AudioManager.RINGER_MODE_NORMAL
                }
                ActionResult.Done("Phone set to $mode.")
            } catch (e: SecurityException) {
                start(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                ActionResult.Done("Android needs Do Not Disturb access for that. I've opened the setting.")
            }
        }
        m("(?:turn |switch )?(?:on|off|toggle) (?:the )?wi-?fi|wi-?fi (?:on|off)", s)?.let {
            val i = if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
            start(ctx, i)
            return ActionResult.Done("Android doesn't let apps switch Wi-Fi directly, so I've opened the connectivity panel for you.")
        }
        m("(?:turn |switch )?(?:on|off|toggle) (?:the )?bluetooth|bluetooth (?:on|off)", s)?.let {
            start(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            return ActionResult.Done("Android doesn't let apps switch Bluetooth directly, so I've opened Bluetooth settings.")
        }
        m("(?:answer|accept|pick up)(?: the| this| my)?(?: incoming)? (?:call|phone)", s)?.let {
            if (!has(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) {
                return ActionResult.NeedPermission(listOf(Manifest.permission.ANSWER_PHONE_CALLS), "To answer calls for you I need the phone permission.", s)
            }
            return try {
                (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
                ActionResult.Done("Answering.")
            } catch (e: SecurityException) {
                ActionResult.Done("I wasn't allowed to answer that call.")
            }
        }
        m("(?:decline|reject|refuse|hang up|end)(?: the| this| my)?(?: incoming)? (?:call|phone)|hang up", s)?.let {
            if (Build.VERSION.SDK_INT < 28) return ActionResult.Done("This version of Android doesn't let me end calls by voice.")
            if (!has(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) {
                return ActionResult.NeedPermission(listOf(Manifest.permission.ANSWER_PHONE_CALLS), "To end calls for you I need the phone permission.", s)
            }
            return try {
                val ended = (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()
                ActionResult.Done(if (ended) "Done." else "There's no call to end.")
            } catch (e: SecurityException) {
                ActionResult.Done("I wasn't allowed to end that call.")
            }
        }
        return ScreenControl.handle(ctx, s)
    }
}
