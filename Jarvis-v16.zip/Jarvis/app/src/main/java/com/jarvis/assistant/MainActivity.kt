package com.jarvis.assistant

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels

class MainActivity : FragmentActivity() {
    private val vm: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { JarvisTheme { JarvisScreen() } }
        if (savedInstanceState == null) handleWake(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWake(intent)
    }

    private fun handleWake(i: Intent?) {
        if (i?.getBooleanExtra("wake", false) == true) { i.removeExtra("wake"); vm.onWake() }
        if (i?.getBooleanExtra("resume", false) == true) {
            i.removeExtra("resume")
            if (SecureStore.of(this).wakeEnabled) WakeService.start(this)
        }
        val retry = i?.getStringExtra("retry")
        if (retry != null) { i.removeExtra("retry"); if (Auth.isUnlocked()) vm.submit(retry) }
    }

    // While the app is on screen it owns the microphone; the background listener steps aside.
    override fun onResume() { super.onResume(); WakeService.markVisible(true) }
    override fun onPause() { vm.onBackground(); WakeService.markVisible(false); super.onPause() }
}
