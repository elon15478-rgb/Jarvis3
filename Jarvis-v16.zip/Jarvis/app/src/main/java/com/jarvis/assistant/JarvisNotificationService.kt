package com.jarvis.assistant

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Only runs if the user turns on Notification access for Jarvis in Android settings, and only looks at
 * the apps the user approved in the Control Center. Keeps the 30 most recent in memory (never on disk).
 * Replies are sent only through the app's own reply button, after the user confirmed, or by the
 * auto-reply rule the user switched on in busy mode.
 */
class JarvisNotificationService : NotificationListenerService() {
    private val store by lazy { SecureStore.of(applicationContext) }
    private val lastSpoken = HashMap<String, String>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        // Google Play update alerts are not personal, so they need no approval.
        if (pkg == "com.android.vending") {
            if (store.proactiveOn && (title + " " + text).contains("update", true)) {
                Proactive.deliver(applicationContext, "App updates", ("Google Play says: $title $text").trim(), true)
            }
            return
        }
        if (!store.allowedApps().contains(pkg)) return

        // Newest message and its sender (for chat apps that use the messaging style).
        var latest = text
        var sender = ""
        @Suppress("DEPRECATION")
        val msgs = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (msgs != null && msgs.isNotEmpty()) {
            val b = msgs[msgs.size - 1] as? Bundle
            if (b != null) {
                latest = b.getCharSequence("text")?.toString() ?: text
                sender = b.getCharSequence("sender")?.toString().orEmpty()
            }
        }
        val isGroup = extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)
        if (store.skipCodes && looksLikeCode(title + " " + latest)) return

        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (ex: Exception) { pkg }

        var replyAction: Notification.Action? = null
        var replyInput: RemoteInput? = null
        for (a in n.actions ?: emptyArray<Notification.Action>()) {
            val r = a.remoteInputs?.firstOrNull { it.allowFreeFormInput }
            if (r != null) { replyAction = a; replyInput = r; break }
        }
        val item = Item(
            sbn.key, app, title, latest, replyAction, replyInput, n.category.orEmpty(),
            pkg, sender, isGroup, System.currentTimeMillis()
        )
        synchronized(recent) {
            recent.removeAll { it.key == item.key }
            recent.add(0, item)
            while (recent.size > 30) recent.removeAt(recent.lastIndex)
        }

        // Busy mode: the user has told Jarvis to answer for them (never in group chats, at most once an hour).
        if (store.busyMode && store.autoReply && replyAction != null && !isGroup && store.autoReplyApps().contains(pkg)) {
            AutoReply.maybe(applicationContext, store, item)
            return
        }
        if (store.readAloud && lastSpoken[sbn.key] != latest) {
            lastSpoken[sbn.key] = latest
            WakeService.announce(item)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        lastSpoken.remove(sbn.key)
        synchronized(recent) { recent.removeAll { it.key == sbn.key } }
    }

    private fun looksLikeCode(s: String): Boolean =
        Regex("\\b\\d{4,8}\\b").containsMatchIn(s) &&
            Regex("code|otp|verification|passcode|one-time|\\bpin\\b", RegexOption.IGNORE_CASE).containsMatchIn(s)

    data class Item(
        val key: String, val app: String, val title: String, val text: String,
        val action: Notification.Action?, val input: RemoteInput?, val category: String,
        val pkg: String = "", val sender: String = "", val isGroup: Boolean = false, val time: Long = 0L
    )

    companion object {
        val recent = mutableListOf<Item>()

        /** Sends [message] through the notification's own reply button. */
        fun sendReply(ctx: Context, item: Item, message: String): Boolean {
            val action = item.action ?: return false
            val input = item.input ?: return false
            return try {
                val intent = Intent()
                val bundle = Bundle()
                bundle.putCharSequence(input.resultKey, message)
                RemoteInput.addResultsToIntent(arrayOf(input), intent, bundle)
                action.actionIntent.send(ctx, 0, intent)
                true
            } catch (e: PendingIntent.CanceledException) {
                false
            } catch (e: Exception) {
                false
            }
        }
    }
}

/** The busy-mode auto-reply rule the owner switched on. Always says it is an automated reply. */
object AutoReply {
    private val last = HashMap<String, Long>()

    fun maybe(ctx: Context, store: SecureStore, item: JarvisNotificationService.Item) {
        val key = item.pkg + "|" + item.title
        val now = System.currentTimeMillis()
        val prev = last[key] ?: 0L
        if (now - prev < 3_600_000L) return
        last[key] = now
        val ok = JarvisNotificationService.sendReply(ctx, item, store.autoReplyText)
        History.log(ctx, (if (ok) "Auto-replied to " else "Auto-reply failed for ") + item.title.ifBlank { "a contact" } + " on " + item.app)
    }
}
