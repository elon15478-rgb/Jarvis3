package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.app.NotificationCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Jarvis's own tasks that run without a voice command: daily briefing, low battery, unanswered messages. */
object Proactive {
    private const val CH = "jarvis_alerts"
    private val nagged = HashSet<String>()

    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequest.Builder(ProactiveWorker::class.java, 15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("jarvis_proactive", ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun cancel(ctx: Context) { WorkManager.getInstance(ctx).cancelUniqueWork("jarvis_proactive") }

    /** Call after any proactive setting changes. */
    fun refresh(ctx: Context) {
        val s = SecureStore.of(ctx)
        if (s.briefingOn || s.proactiveOn) schedule(ctx) else cancel(ctx)
    }

    fun run(ctx: Context) {
        val s = SecureStore.of(ctx)
        if (s.briefingOn) {
            val cal = Calendar.getInstance()
            val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            val target = s.briefingHour * 60 + s.briefingMin
            val dayKey = cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR)
            if (nowMin >= target && nowMin < target + 30 && s.briefingLastDay != dayKey) {
                s.briefingLastDay = dayKey
                deliver(ctx, "Your daily briefing", briefing(ctx, s), true)
            }
        }
        if (s.proactiveOn) {
            battery(ctx, s)
            unanswered(ctx)
        }
    }

    private fun batteryLevel(ctx: Context): Pair<Int, Boolean> {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return Pair(if (level < 0) -1 else level * 100 / scale, charging)
    }

    private fun briefing(ctx: Context, s: SecureStore): String {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val part = if (h < 12) "morning" else if (h < 18) "afternoon" else "evening"
        val sb = StringBuilder()
        sb.append("Good ").append(part).append(", ").append(s.ownerName).append(". It's ")
            .append(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())).append(" on ")
            .append(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())).append(". ")
        val (pct, charging) = batteryLevel(ctx)
        if (pct >= 0) sb.append("Battery is at ").append(pct).append(" percent").append(if (charging) " and charging. " else ". ")
        val now = System.currentTimeMillis()
        val today = Reminders.all(ctx).filter { it.at - now in 0L..86_400_000L }.sortedBy { it.at }
        if (today.isNotEmpty()) {
            val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
            sb.append("You have ").append(today.size).append(if (today.size == 1) " reminder: " else " reminders: ")
                .append(today.joinToString(", ") { it.text + " at " + fmt.format(Date(it.at)) }).append(". ")
        } else sb.append("You have no reminders in the next day. ")
        val counts = synchronized(JarvisNotificationService.recent) {
            JarvisNotificationService.recent.groupingBy { it.app }.eachCount()
        }
        if (counts.isNotEmpty()) {
            sb.append("Waiting notifications: ").append(counts.entries.joinToString(", ") { it.value.toString() + " from " + it.key }).append(".")
        }
        return sb.toString().trim()
    }

    private fun battery(ctx: Context, s: SecureStore) {
        val (pct, charging) = batteryLevel(ctx)
        if (pct in 0..14 && !charging && !s.lowBatteryNotified) {
            s.lowBatteryNotified = true
            deliver(ctx, "Battery low", "Battery is at $pct percent. You may want to charge your phone soon.", true)
        } else if (pct >= 25 || charging) {
            s.lowBatteryNotified = false
        }
    }

    private fun unanswered(ctx: Context) {
        val limit = System.currentTimeMillis() - 30 * 60_000L
        val items = synchronized(JarvisNotificationService.recent) {
            JarvisNotificationService.recent.filter { it.action != null && !it.isGroup && it.time in 1L..limit }
        }
        for (i in items.take(2)) {
            if (nagged.add(i.key)) {
                deliver(ctx, "Unanswered message",
                    "You haven't replied to " + i.sender.ifBlank { i.title } + " on " + i.app + ". Say reply to the last message to answer.", true)
            }
        }
    }

    /** Shows a notification and, if Jarvis is listening and the owner is verified, says it out loud. */
    fun deliver(ctx: Context, title: String, text: String, speak: Boolean) {
        val unlocked = Auth.isUnlocked()
        val shown = if (unlocked) text else "Unlock Jarvis to see this."
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Jarvis alerts", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(ctx, 7, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(shown)
            .setStyle(NotificationCompat.BigTextStyle().bigText(shown))
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        nm.notify((System.currentTimeMillis() % 100_000L).toInt() + 1000, n)
        History.log(ctx, "Alert: $title")
        if (speak && unlocked) WakeService.alert(text)
    }

    /** After a restart Android does not let microphone services start by themselves, so offer a one-tap resume. */
    fun onBoot(ctx: Context) {
        refresh(ctx)
        if (!SecureStore.of(ctx).wakeEnabled) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Jarvis alerts", NotificationManager.IMPORTANCE_DEFAULT))
        val resume = PendingIntent.getActivity(
            ctx, 8, Intent(ctx, MainActivity::class.java).putExtra("resume", true), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis stopped listening")
            .setContentText("Tap to start listening again.")
            .setAutoCancel(true)
            .setContentIntent(resume)
            .build()
        nm.notify(9001, n)
    }
}

class ProactiveWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try { Proactive.run(applicationContext) } catch (e: Exception) { }
        return Result.success()
    }
}
